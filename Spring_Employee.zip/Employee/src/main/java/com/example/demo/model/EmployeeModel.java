package com.example.demo.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class EmployeeModel {

	@Id
	int Eid;
	String Ename;
	String Etech;
	public int getEid() {
		return Eid;
	}
	public void setEid(int eid) {
		Eid = eid;
	}
	public String getEname() {
		return Ename;
	}
	public void setEname(String ename) {
		Ename = ename;
	}
	public String getEtech() {
		return Etech;
	}
	public void setEtech(String etech) {
		Etech = etech;
	}
	@Override
	public String toString() {
		return "EmployeeModel [Eid=" + Eid + ", Ename=" + Ename + ", Etech=" + Etech + "]";
	}
	
	
}
